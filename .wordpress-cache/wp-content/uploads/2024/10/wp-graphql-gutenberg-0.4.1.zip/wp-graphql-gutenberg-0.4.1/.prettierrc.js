module.exports = {
	...require( '@wordpress/scripts/config/.prettierrc.js' ),
	trailingCommaPHP: false,
	braceStyle: '1tbs',
	printWidth: 120,
};
